import Link from "next/link"

import { source } from "@/lib/source"

export function ComponentsList() {
  const components = source.pageTree.children.find(
    (page) => page.$id === "components"
  )

  if (components?.type !== "folder") {
    return
  }

  const list = components.children.filter(
    (component) => component.type === "page"
  )

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 md:gap-x-6 lg:gap-y-6">
      {list.map((component) => (
        <Link
          key={component.$id}
          href={component.url}
          className="text-base font-medium underline-offset-4 hover:underline"
        >
          {component.name}
        </Link>
      ))}
    </div>
  )
}
